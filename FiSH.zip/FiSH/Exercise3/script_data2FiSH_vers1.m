% this code reads data stored in the Fault2SHA_CentralApennines_Database.xls
% and coordinates of MainFaults according to the files given in the
% folder MainFaults_lonlat
% and produces a file that can be read by the mb.m code inthe FiSH package
% (Pace et al., 2016).
% name ScR Length Dip Seismogenic_Thickness SRmin SRmax Mobs sdMobs Last_eq_time

% in the USER OPTIONS sections:

% The user has 2 options to calculate the average slip rate of a fault:
% a) arithmetic mean of the slip rate collected along the fault
% b) integral average assuming to have a slip rate = 0 at the tips of the fault

% The user defines:
% 1) the maximum distance for which a point with slip rate is associated to the fault
% 2) the prefix of the output files name
% 3) other variables required by FiSH


%%
clear all
clc
close all
warning('off','all')
addpath ('INPUTS/','INPUTS/MainFaults_lonlat/')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dmax = 500; % in meters, specify the maximum distance to associate a point to a Mainfault
maxdiffUTM=100; % in meters, specify the max difference between two vertexes when resampling the Mainfault trace
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% USER OPTIONS
extrapolate_slip_rate_option = 1; % 1= mean of a profile with tip to 0mm/year, 2 = mean of the data 
outputname = 'test1'; % this is the prefix in the output files
% mb.m required parameters that are not in the DB
SeismThick = 10; % in km, this is a parameter for FiSH
ScR = 'WC94-N'; % this is code used by FiSH
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% make output directory
pathout1 = fullfile('OUTPUT','figure');
pathout2 = fullfile('OUTPUT','table');
 
if isdir(pathout1)==0
mkdir (pathout1)
end
if isdir(pathout2)==0
mkdir (pathout2)
end

fid_geom = fopen(fullfile(pathout2,strcat('Faults_geometry_',outputname,'.txt')),'w');
formatgeom = '%s\t%s\t%s\t%s\n';
fprintf(fid_geom,'model_name fault_name longitude latitude\n');

T = table(); % this is the table saved at the end of the script
%% read the DB-excel format
db = 'Fault2SHA_CentralApennines_Database_2021_v1_xls2013.xlsx';
[fault_data,Mainfault_names,~] = xlsread (db,'Fault');
[Mainfault_data,Mainfault_names2,~] = xlsread (db,'MainFault');
[sliprate_data,sliprate_TXT5,~] = xlsread (db,'SlipRate');
[localgeomKin_data,localgeomKin_TXT6,~] = xlsread (db,'LocalGeometryKinematics');

[~,Mainfault_selection,~] = xlsread (db,'MainFaultOptionChoice','E7:E12');
R = Mainfault_selection;
display ('You have selected the following Main fault options')
R(~cellfun('isempty',R))
% faults name listed in the DB
Mainfaults_all = Mainfault_names(2:end,4);
Mainfaults = unique(Mainfaults_all)
% number of Mainfaults in the DB
n_Mainfault = size(Mainfaults,1);
fprintf('you defined a list of %i Mainfaults from the DB\n', n_Mainfault)

%%
for nf = 1:n_Mainfault
    temp = table(); % temporary table used to append data to T that is saved at the end of the script
    Mainfault =[];
    Mainfault = char(Mainfaults(nf,:));
    % if Mainfaults exists in the folder MainFaults_lonlat load coordinates of the Mainfaults
    in_name_Mainfault = fullfile('MainFaults_lonlat',strcat(Mainfault,'.txt'));
    if exist(in_name_Mainfault) ~= 2 % if a file exist the value is 2
      fprintf(['there are no coordinates of the ', Mainfault,' in the folder\n'])
    else  % use this MainFault
    coordinateUTM=[];coordinateWGS=[];
        coordinateWGS = load(in_name_Mainfault);

%% position of the fault in the excel-Sheets of DB 
h1 = find(strcmp(Mainfault_names2(:,2),Mainfault))-1; % position-header
h5 = find(strcmp(sliprate_TXT5(:,4),Mainfault))-1; % position-header
h6 = find(strcmp(localgeomKin_TXT6(:,4),Mainfault))-1; % position-header

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate the average dip from LocalGeometryKinematics 
average_dip = round(nanmean(localgeomKin_data(h6,8)),0); % average of dip along the entire FAULT, not for section
average_dip(isnan(average_dip))= 60;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CHECK if the order of the vertexes of the fault are given according to right-hand rule

strike = Mainfault_data(h1,3);
az = azimuth(coordinateWGS(1,2),coordinateWGS(1,1),coordinateWGS(end,2),coordinateWGS(end,1));

d1 = az - strike;
d2 = az - (strike+180);
if abs(d2) < abs(d1)
    coordinateWGS = flipud(coordinateWGS);
end
[coordinateUTM(:,1),coordinateUTM(:,2),utmzonekml] = deg2utm(coordinateWGS(:,2),coordinateWGS(:,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save coordinates of the section in the fault_geom
%example tol=0.005 is roughly 500 meters
    
    [lat1, lon1, cerr, tol] = reducem(coordinateUTM(:,1),coordinateUTM(:,2),500);
    simplified = [];
    simplified = [lat1,lon1];
    
    utmzone = repmat(utmzonekml(1,:),size(simplified,1),1);
    [Lat,Lon] = utm2deg(simplified(:,1),simplified(:,2),utmzone);
    for j = 1: size(Lat,1)
    fprintf(fid_geom,formatgeom, outputname,Mainfault,num2str(Lon(j)), num2str(Lat(j)));
    
    end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% extract slip rate coordinates from the DB
period = sliprate_data(h5,[36]);
slipratecoordinateWGS = sliprate_data(h5,[16,17]);
slipratecoordinateUTM = sliprate_data(h5,[13,14]);
% calculate slip rate from slip and Throw in the DB
slipratePreferred     = sliprate_data(h5,24)./period; %
sliprateError         = sliprate_data(h5,[25,26])./[period, period];
SlipFromThrowPreferred        = (sliprate_data(h5,27)./sind(average_dip))./period;
SlipFromThrowError            = (sliprate_data(h5,[28,29])./sind(average_dip))./[period, period];

% if there are NaN values of slip rates in the database, (example
% pizzalto,MtVettore)
% we use throw and average dip to calculate the slip

hnan=[];
hnan = find(isnan(slipratePreferred));
slipratePreferred(hnan,:) = SlipFromThrowPreferred(hnan,:);
sliprateError(hnan,:)=SlipFromThrowError(hnan,:);
hnan=[];
%% if you still have NaN then we remove that point!
hnan = find(isnan(slipratePreferred));
if ~isempty(hnan)
slipratecoordinateWGS(hnan,:)=[];
slipratecoordinateUTM(hnan,:) = [];
slipratePreferred(hnan,:) = [];
sliprateError(hnan,:)=[];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if sum(slipratePreferred >0) % at least a value of slip rate
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% cumulative fault trace length
for i = 1:(size(coordinateUTM,1)-1)
    d_trace(i+1) = sqrt((coordinateUTM(i,1)-coordinateUTM((i+1),1))^2+...
           (coordinateUTM(i,2)-coordinateUTM((i+1),2))^2);

end
fault_cumsum_length = cumsum(d_trace);
fault_length = fault_cumsum_length(end);


% resample the fault trace
% the resampled trace is used to attribute point with slip rate to the
% fault

[y_fault_resUTM, x_fault_resUTM] = interpm(coordinateUTM(:,2),coordinateUTM(:,1),maxdiffUTM);
%%% check to remove double points
check_x=diff(x_fault_resUTM);
check_y=diff(y_fault_resUTM);

repeated_points=find(check_x<=1 & check_y<=1); % remove points with <1m distance to each other
x_fault_resUTM(repeated_points)=[];
y_fault_resUTM(repeated_points)=[]; 


% cumulative resampled-fault trace length
d_trace_resUTM =[];
 for i = 1:(length(x_fault_resUTM)-1)
     d_trace_resUTM(i+1) = sqrt((x_fault_resUTM(i,1)-x_fault_resUTM((i+1),1))^2+...
            (y_fault_resUTM(i,1)-y_fault_resUTM((i+1),1))^2);
 
 end
 
 resfault_cumsum_length =[];
 resfault_cumsum_length = cumsum(d_trace_resUTM);
 resfault_length = resfault_cumsum_length(end);

 
 

% associate the nearest point of the resampled fault trace
    d=[];min_d=[];
    for i = 1:size(slipratePreferred,1)
        temp_dist =[];
        temp_dist = sqrt((slipratecoordinateUTM(i,1)-x_fault_resUTM).^2+...
                         (slipratecoordinateUTM(i,2)-y_fault_resUTM).^2 );
                     
        d(i,1) = find(temp_dist==min(temp_dist),1,'first'); %save the ordinal position 
        min_d(i,1) =min(temp_dist);
    end
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   % remove points with distance >min_d(m)
       d_outlimit = find(min_d>dmax);
       slipratePreferred(d_outlimit) = [];
       sliprateError(d_outlimit,:) = [];
       slipratecoordinateWGS(d_outlimit,:) = [];
       slipratecoordinateUTM(d_outlimit,:) = [];
       d(d_outlimit) = []; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   if sum(slipratePreferred >0) % again, after removing points check if at least a positive slip rate exists   
    
distance_sliprate = resfault_cumsum_length(d);
% check if two or more meausures are on the same point
u = unique(distance_sliprate);
if length(u) < length(distance_sliprate)
    fprintf([Mainfault,' there are 2 or more measures at the same location (used the mean) >>\n'])
    distanza_sliprate_2   =[];slipratePreferred_2   =[];sliprateError_2       =[];
    slipratecoordinateWGS_2 =[];slipratecoordinateUTM_2 =[];   
    for iu = 1:length(u)
       hu = find( distance_sliprate == u(iu));
       distanza_sliprate_2(iu) = mean(distance_sliprate(hu));
       slipratePreferred_2(iu,1) = mean(slipratePreferred(hu));
       sliprateError_2(iu,:) = mean(sliprateError(hu,:),1);
       slipratecoordinateWGS_2(iu,:) = mean(slipratecoordinateWGS(hu,:),1);
       slipratecoordinateUTM_2(iu,:) = mean(slipratecoordinateUTM(hu,:),1);
    end
    distance_sliprate       =[];slipratePreferred   = [];sliprateError       = [];
    slipratecoordinateWGS   = [];slipratecoordinateUTM = [];
    
    distance_sliprate       = distanza_sliprate_2;
    slipratePreferred       = slipratePreferred_2;
    sliprateError           = sliprateError_2;
    slipratecoordinateWGS   = slipratecoordinateWGS_2;
    slipratecoordinateUTM   = slipratecoordinateUTM_2;
    
end

%%
% calculate average slip rate for the fault

    if extrapolate_slip_rate_option == 1

        if (min(distance_sliprate) == resfault_cumsum_length(1)) & (max(distance_sliprate) ~= resfault_cumsum_length(end))
                slipratecoordinateWGS = [slipratecoordinateWGS;coordinateWGS(end,:)];
                distance_sliprate   = [distance_sliprate,resfault_cumsum_length(end)];
                slipratePreferred   = [slipratePreferred;0];
                sliprateError       = [sliprateError;0,0];
        elseif (min(distance_sliprate) ~=resfault_cumsum_length(1)) & (max(distance_sliprate) == resfault_cumsum_length(end))
                slipratecoordinateWGS = [coordinateWGS(1,:);slipratecoordinateWGS];
                distance_sliprate   = [resfault_cumsum_length(1),distance_sliprate];
                slipratePreferred   = [0;slipratePreferred];
                sliprateError       = [0,0;sliprateError];    
        else   
            
    slipratecoordinateWGS = [coordinateWGS(1,:);slipratecoordinateWGS;coordinateWGS(end,:)];
    distance_sliprate   = [resfault_cumsum_length(1),distance_sliprate,resfault_cumsum_length(end)];
    slipratePreferred   = [0;slipratePreferred;0];
    sliprateError       = [0,0;sliprateError;0,0];
        end
        
% interpolate slip rate to build a profile        
    slipRateProfilePreferred = interp1(distance_sliprate,slipratePreferred,resfault_cumsum_length);
    slipRateProfileMin = interp1(distance_sliprate,sliprateError(:,1),resfault_cumsum_length);
    slipRateProfileMax = interp1(distance_sliprate,sliprateError(:,2),resfault_cumsum_length);
% integral average of the slip rate profile 
    a= min(distance_sliprate);
    b= max(distance_sliprate);
    AverageSlipRatePreferred=(1/(b-a))*trapz(distance_sliprate,slipratePreferred);
    AverageSlipRateMin=(1/(b-a))*trapz(distance_sliprate,sliprateError(:,1));
    AverageSlipRateMax=(1/(b-a))*trapz(distance_sliprate,sliprateError(:,2));
 
    elseif extrapolate_slip_rate_option == 2
 % mean of the data, no interpolation
    
    AverageSlipRatePreferred = mean(slipratePreferred);
    AverageSlipRateMin = mean(sliprateError(:,1));
    AverageSlipRateMax = mean(sliprateError(:,2));
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% save data in a table format
temp.name = {Mainfault};
temp.ScR = ScR;
temp.Length = round(resfault_length/1000,1);
temp.Dip = average_dip;
temp.Seismogenic_Thickness = SeismThick;
temp.SRmin = round(AverageSlipRateMin,2);
temp.SRmax = round(AverageSlipRateMax,2);
temp.Mobs = NaN;
temp.sdMobs = NaN;
temp.Last_eq_time = NaN;

T = vertcat(T,temp);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% make a figure for each fault
figure(1)
leg=[];
hleg = 0;
hold on

if extrapolate_slip_rate_option == 1
    hleg = hleg+1;
leg(1,hleg) = plot(resfault_cumsum_length,slipRateProfilePreferred,'-','color',[.5 .5 .5],'LineWidth',2,'Display','Interpolated Preferred');
hleg = hleg+1;
leg(1,hleg) = plot(resfault_cumsum_length,slipRateProfileMin,':','color',[.5 .5 .5],'LineWidth',2,'Display','Interpolated Min Max');
                plot(resfault_cumsum_length,slipRateProfileMax,':','color',[.5 .5 .5],'LineWidth',2,'Display','InterpolatedMax');
hleg = hleg+1;
leg(1,hleg) =  line([distance_sliprate(1),distance_sliprate(end)],[AverageSlipRatePreferred,AverageSlipRatePreferred],'color','c','LineWidth',1,'Display','Avg Preferred');
hleg = hleg+1;
leg(1,hleg) =  plot([distance_sliprate(1),distance_sliprate(end)],[AverageSlipRateMin,AverageSlipRateMin],':','color','c','LineWidth',1,'Display','Avg Min Max');
            plot([distance_sliprate(1),distance_sliprate(end)],[AverageSlipRateMax,AverageSlipRateMax],':','color','c','LineWidth',1,'Display','Avg Max');

elseif extrapolate_slip_rate_option == 2 | extrapolate_slip_rate_option == 3
   hleg = hleg+1;
leg(1,hleg) = line([resfault_cumsum_length(1),resfault_cumsum_length(end)],[AverageSlipRatePreferred,AverageSlipRatePreferred],'color','c','LineWidth',1,'Display','Avg Preferred');
   hleg = hleg+1;
leg(1,hleg) = plot([resfault_cumsum_length(1),resfault_cumsum_length(end)],[AverageSlipRateMin,AverageSlipRateMin],':','color','c','LineWidth',1,'Display','Avg Min Max');
  hleg = hleg+1;
leg(1,hleg) =  plot([resfault_cumsum_length(1),resfault_cumsum_length(end)],[AverageSlipRateMax,AverageSlipRateMax],':','color','c','LineWidth',1,'Display','Avg Min Max');

end


hleg = hleg+1;

leg(1,hleg)=errorbar(distance_sliprate,slipratePreferred,(slipratePreferred-sliprateError(:,1)),(sliprateError(:,2)-slipratePreferred),...
    'Marker','s','MarkerFaceColor','w','LineStyle','none', 'MarkerEdgeColor','k','Color','k','Display','DataPoints');
xlabel('distance along strike (km)')
ylabel ('mm/yr')
legend(leg,'location','best')

% add rough orientation of the fault strike
label1 = {'S','SW', 'NW', 'N','N','NW', 'SW', 'S'};
label2 = {'N','NE', 'SE', 'S','S','SE', 'NE', 'N'};
limits = [0 45 90 135 180 225 270 315 360];
label_pos = find(histcounts(strike,limits)==1);
text(-1500,AverageSlipRatePreferred,label1(label_pos));
text((resfault_length+500),AverageSlipRatePreferred,label2(label_pos));

xlim([-2000,resfault_length+1000])
ylim([0 3])

set(gca, 'XTick',[-2000:2000:(resfault_length+500)],'XTickLabel',{'',(0:2000:(resfault_length+500))/1000})


saveas(1,fullfile(pathout1,strcat(outputname,Mainfault,'_','_sliprates_profile_option',num2str(extrapolate_slip_rate_option),'_',date,'.png')),'png')
print(fullfile(pathout1,strcat(outputname,'_',Mainfault,'_sliprates_profile_option',num2str(extrapolate_slip_rate_option),'_',date,'.tiff')),'-dtiff','-r600');
close(1);
end
end
    end
end

% save the file that can be used by mb.m in FiSH
writetable(T,fullfile(pathout2,strcat(outputname,'_input_mb','.txt')),'Delimiter','tab');
fclose(fid_geom);
