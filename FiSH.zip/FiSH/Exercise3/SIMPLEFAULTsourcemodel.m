% build the OQ xml source model input

clear all
close all
clc
%%
pathout = fullfile('OUTPUT','OQsourcemodel');
if isdir(pathout)==0
mkdir (pathout)
end
%%
modelname='case 1'; % please, set your modelname, this is written in the xml file

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% read rates, geoemtry and coordinates
%ar_rates = readtable('output_files/test4_AR_SinglePoisson_rates.txt');
ar_rates = readtable('output_files/ex3_AR_ChGaussPoisson_rates.txt');

if size(ar_rates,2) == 5
Mainfaults = ar_rates.Var5;
table_rates = ar_rates.Var4;
elseif size(ar_rates,2) == 4
Mainfaults = ar_rates.Var4;
table_rates = ar_rates.Var3;
end

n_Mainfault = size(Mainfaults,1);

geometry = readtable('OUTPUT/table/test1_input_mb.txt');
Mainfault2 = geometry.name;

coordinates = readtable('OUTPUT/table/Faults_geometry_test1.txt');
Mainfault3 = coordinates.Var2;

%%
fidOQ=fopen(fullfile(pathout,'ex3.xml'),'w'); % please, set your filename.xml, this is the name of your file


fprintf(fidOQ, '<?xml version="1.0" encoding="UTF-8"?>\n\n');
fprintf(fidOQ,'<nrml xmlns="http://openquake.org/xmlns/nrml/0.4" xmlns:gml="http://www.opengis.net/gml">\n');
fprintf(fidOQ,strcat(strcat([blanks(3),'<sourceModel name="', modelname,'">\n'])));
%%
for nf = 1:n_Mainfault
   Mainfault =[];
    Mainfault = char(Mainfaults(nf,:)); 
    
   %% position of the fault in the coordinates and geoemtry files 
   h1 = [];
   h1 = find(strcmp(deblank (Mainfault3),deblank (Mainfault)));
   h2 = [];
   h2 = find(strcmp(deblank (Mainfault2),deblank (Mainfault)));
 if ~isempty(h1)
     if size(ar_rates,2)==4
         binWidth = 0.1;
     else
        binWidth = ar_rates.Var3(nf);
     end
     minMag = ar_rates.Var2(nf) + binWidth/2;
     
     if size(ar_rates,2) == 5
        rates = table_rates{nf};
     elseif size(ar_rates,2) == 4
        rates = num2str(table_rates(nf));
     end
     vert=[];
     vert = [coordinates.Var3(h1),coordinates.Var4(h1)];
     
    
fprintf(fidOQ,strcat([blanks(0),'<simpleFaultSource id="',num2str(ar_rates.Var1(nf)),'" name="', Mainfault,'" tectonicRegion="Active Shallow Crust">\n']));
fprintf(fidOQ,strcat([blanks(4),'<simpleFaultGeometry>\n']));
fprintf(fidOQ,strcat([blanks(5),'<gml:LineString>\n']));
fprintf(fidOQ,strcat([blanks(13),'<gml:posList>\n']));
for nv=1:size(vert,1)
   fprintf(fidOQ,strcat([blanks(17),num2str(vert(nv,1)),blanks(1),num2str(vert(nv,2)),'\n']));

end
fprintf(fidOQ,strcat([blanks(13),'</gml:posList>\n']));
fprintf(fidOQ,strcat([blanks(5),'</gml:LineString>\n']));

fprintf(fidOQ,strcat([blanks(5),'<dip>',num2str(geometry.Dip(nf)),'</dip>\n']));
fprintf(fidOQ,strcat([blanks(5),'<upperSeismoDepth>',num2str(0),'</upperSeismoDepth>\n'])); % assume all faults have a upper seismo depth = 0km
fprintf(fidOQ,strcat([blanks(5),'<lowerSeismoDepth>',num2str(geometry.Seismogenic_Thickness(nf)),'</lowerSeismoDepth>\n']));%assume all faults have a upper seismo depth = 0km

fprintf(fidOQ,strcat([blanks(5),'</simpleFaultGeometry>\n']));

fprintf(fidOQ,strcat([blanks(1),'<magScaleRel>WC1994</magScaleRel>\n']));
fprintf(fidOQ,strcat([blanks(1),'<ruptAspectRatio>1</ruptAspectRatio>\n']));

fprintf(fidOQ,strcat([blanks(1),'<incrementalMFD minMag="',num2str(minMag),'" binWidth="',num2str(binWidth),'">\n']));
fprintf(fidOQ,strcat([blanks(5),'<occurRates>',rates,'</occurRates>\n']));
fprintf(fidOQ,strcat([blanks(1),'</incrementalMFD>\n']));

fprintf(fidOQ,strcat([blanks(5),'<rake>',num2str(-90),'</rake>\n']));

fprintf(fidOQ,strcat([blanks(0),'</simpleFaultSource>\n']));
 
     
     
 end
end



fprintf(fidOQ,strcat([blanks(3),'</sourceModel>\n']));
fprintf(fidOQ,'</nrml>');
fclose('all');
