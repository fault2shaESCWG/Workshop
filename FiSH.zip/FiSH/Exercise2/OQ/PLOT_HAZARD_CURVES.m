% plot hazard curves


clear all
clc


%% set inputs here
run=[27,28,29];
SA={'PGA'};

site = [13.096, 42.79105]; %NORCIA
maxdist =0.1;% this in degree, but for our purpose is ok 
%%
pathresults = 'OUTPUT';
file1 = readtable(fullfile(strcat('hazard_curve-mean-',char(SA),'_',num2str(run(1)),'.csv')),'HeaderLines',1);
file2 = readtable(fullfile(strcat('hazard_curve-mean-',char(SA),'_',num2str(run(2)),'.csv')),'HeaderLines',1);
file3 = readtable(fullfile(strcat('hazard_curve-mean-',char(SA),'_',num2str(run(3)),'.csv')),'HeaderLines',1);

%%
coord = table2array(file1(:,1:2));
data1 = table2array(file1(:,4:end));

iml = file1.Properties.VariableNames;
IML_1=strrep(iml,'poe_','');IML_1=strrep(IML_1,'_','.');
IML_1 = (IML_1(4:end));
IML=str2num(char(IML_1));
IML = IML';

data2 = table2array(file2(:,4:end));

data3 = table2array(file3(:,4:end));

for n_site=1:size(site,1) 
    
 
 row_site=[];
 distanza=sqrt((coord(:,1)-site(n_site,1)).^2 +  (coord(:,2)-site(n_site,2)).^2);
 row_site=find(distanza==min(distanza));
 
 if min(distanza) <= maxdist % this in degree, but for the purpose is ok 
     

figure(1)
hold on
 
plot(IML,data1(row_site,:),'-','LineWidth',2.0,'Color',[1 0 0],'Display','case1');
plot(IML,data2(row_site,:),'-','LineWidth',2.0,'Color',[0 1 0],'Display','case2');
plot(IML,data3(row_site,:),'-','LineWidth',2.0,'Color',[0 0 1],'Display','case3');

hold off
     grid on
     set(gca,'XScale','log','YScale','log','fontsize',12,'fontname','Arial');
     ylim([1e-3 1])
     xlim([IML(1) IML(end)])
         xlabel('IML (PGA[g])')
         ylabel('POE')
         
     axis square
     end
end

