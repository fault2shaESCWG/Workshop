function [outputname]=CHGaussProb(c,d,outputfilename,faultname,mag,sdmag,Tmean,Morate,id,nfault,w,ProbabilityOfOccurrence,bin)

outputname=strcat(outputfilename,'_AR_ChGaussProb', '.txt');
   
  % open a file for writing the output
fidout = fopen(strcat('./output_files/',outputname), 'w'); 
% print a title, followed by a blank line
fprintf(fidout, 'id Mmin bin rates name\n');

    
  
%%% calculate a fictious Tmean following Pace et al., 2006
Tfict=[(-1*w)./log(1-ProbabilityOfOccurrence)];
Morate_fict=Morate.*(Tmean./Tfict);    
    



for i=1:nfault  % ciclo per andare aventi con le faglie
  
magnitude_range=(mag(i)-sdmag(i)):bin:(mag(i)+sdmag(i));
M=10.^((c.*magnitude_range)+d);


pdf_mag = pdf('Normal',magnitude_range,mag(i),sdmag(i));
total_moment=sum(pdf_mag.*M);

ratio=(Morate_fict(i))/total_moment;
balanced_pdf_moment=ratio*pdf_mag;

Mo_balanced_fict(i,1)=sum(balanced_pdf_moment.*M);

CHgaussRATES=balanced_pdf_moment;
cumCHgaussRATES=fliplr(cumsum(fliplr(CHgaussRATES)));
Mag_min=magnitude_range(1);
out_Rates=[id(i) Mag_min bin CHgaussRATES];


fprintf(fidout,'%d, %3.1f, %3.1f,',out_Rates(1:3));
fprintf(fidout,'%1s',blanks(1));
for j=1:length(CHgaussRATES)
fprintf(fidout,'%5.4e',CHgaussRATES(j));
fprintf(fidout,'%1s',blanks(1));
end

fprintf(fidout,',%1s',blanks(1));
fprintf(fidout,'%s\n',faultname(i,:));


figure(i)
semilogy(magnitude_range,cumCHgaussRATES,'ok')
fault=faultname(i,:);
figname=strcat('./output_files/', outputfilename,'_AR_ChGaussProb_rates_',fault);
xlabel('magnitude');
ylabel('annual cumulative rates');
title(fault)
saveas(figure(i), figname,'epsc');

end