function [dist_trunc_mag]=truncGaussDist(pdf_magnitudes, x_range_of_mag, M,dM,mag,n_sigma_trunc_magnitudes)


vector_mag=length(M);
dist_trunc_mag(vector_mag,length(x_range_of_mag))=zeros;

for i=1:vector_mag
lower_threshold=(M(i)-n_sigma_trunc_magnitudes*dM(i));
upper_threshold=(M(i)+n_sigma_trunc_magnitudes*dM(i));
lowest_value=find(x_range_of_mag <= lower_threshold,1,'last');
highest_value=find(x_range_of_mag <= upper_threshold,1,'last');
dist_trunc_mag(i,lowest_value:highest_value)=pdf_magnitudes(i,lowest_value:highest_value);
end