function [outputname]=singleBPT(outputfilename,mag,id,nfault,faultname,w,Hbpt)


%%% calculate a fictious Tmean following Pace et al., 2006
Tfict=(-1*w)./log(1-Hbpt);


CH_RATES(:,1)=1./Tfict;
CH_MAGNITUDE(:,1)=mag;
%fprintf(fidout, 'id Mchar rate name\n')
out_Rates = [id, CH_MAGNITUDE,CH_RATES];
out_Prob = [id, CH_MAGNITUDE,repmat(w,nfault,1), Hbpt'];


outputname=strcat(outputfilename,'_AR_SingleBPT_rates', '.txt');

outputnameProbability=strcat(outputfilename,'_AR_SingleBPT_Probability');

% open a file for writing the outputs
fidout = fopen(strcat('./output_files/',outputname), 'w');
% print a title, followed by a blank line
fprintf(fidout, 'id Mchar rate name\n');

fidoutProb = fopen(strcat('./output_files/',outputnameProbability, '.txt'), 'w');
% print a title, followed by a blank line
fprintf(fidoutProb, 'id Mchar window Probability name\n');
%fprintf(fidout, 'id Mchar window Probability name\n')


%%% PLOT figures and SAVE output files
for i =1:nfault
fprintf(fidout,'%d, %3.1f, %5.3e,',out_Rates(i,:));
fprintf(fidout,'%1s',blanks(1));
fprintf(fidout,'%s\n',faultname(i,:));

fprintf(fidoutProb,'%d, %3.1f, %d, %5.3e,',out_Prob(i,:));
fprintf(fidoutProb,'%1s',blanks(1));
fprintf(fidoutProb,'%s\n',faultname(i,:));

figure(i)
semilogy(out_Rates(i,2),out_Rates(i,3),'ok')
fault=faultname(i,:);
figname=strcat('./output_files/', outputfilename,'_AR_SingleBPT_rates_',fault);

xlabel('magnitude');
ylabel('annual rate');
title(fault)
saveas(figure(i), figname,'epsc');

end