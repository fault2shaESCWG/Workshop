function [outputname]=singlePoiss(c,d,outputfilename,faultname,mag,Morate,id,nfault,w,Hpois)



CH_MAGNITUDE(:,1)=mag;
CH_RATES(:,1)=(Morate./(10.^(c.*CH_MAGNITUDE+d)));


out_Rates = [id, CH_MAGNITUDE,CH_RATES];
out_Prob = [id, CH_MAGNITUDE,repmat(w,nfault,1), Hpois'];


outputname=strcat(outputfilename,'_AR_SinglePoisson_rates.txt');
    
outputnameProbability=strcat(outputfilename,'_AR_SinglePoisson_Probability');

% open two files for writing the outputs
fidout = fopen(strcat('./output_files/',outputname), 'w');
% print a title, followed by a blank line
fprintf(fidout, 'id Mchar rate name\n');

fidoutProb = fopen(strcat('./output_files/',outputnameProbability, '.txt'), 'w');
% print a title, followed by a blank line
fprintf(fidoutProb, 'id Mchar window Probability name\n');
%fprintf(fidout, 'id Mchar window Probability name\n')


%%% PLOT figures and SAVE output files
for i =1:nfault
fprintf(fidout,'%d, %3.1f, %5.3e,',out_Rates(i,:));
fprintf(fidout,'%1s',blanks(1));
fprintf(fidout,'%s\n',faultname(i,:));

fprintf(fidoutProb,'%d, %3.1f, %d, %5.3e,',out_Prob(i,:));
fprintf(fidoutProb,'%1s',blanks(1));
fprintf(fidoutProb,'%s\n',faultname(i,:));


figure(i)
semilogy(out_Rates(i,2),out_Rates(i,3),'ok')
fault=faultname(i,:);
figname=strcat('./output_files/', outputfilename,'_AR_SinglePoisson_rates_',fault);%-- 19/10/15 12:53 --%

xlabel('magnitude');
ylabel('annual rate');
title(fault)
saveas(figure(i), figname,'epsc');
end