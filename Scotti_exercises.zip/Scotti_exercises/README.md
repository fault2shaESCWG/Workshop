# CentralApennines
This repository contains all the files and codes necessary to run the Central Apennines model published in Scotti et al. (2020).

To run the codes please refer to the user manual


