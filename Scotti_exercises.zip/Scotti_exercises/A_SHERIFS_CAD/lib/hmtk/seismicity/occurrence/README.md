Occurrence 
=====

The occurrence module contains methods for the calculation of the 
parameters charaterising magnitude-frequency distributions widely
used in seismic hazard analysis.
