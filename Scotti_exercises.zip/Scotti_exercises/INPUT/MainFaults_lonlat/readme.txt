coordinates of the master faults
