this folder contains the shapefiles used to select earthquakes from the cpti15
